/* 
 * DOCUMENTED: Derick Vigne helped with the making of this code 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Jacob Stevens
 */
public class Computer
{

    private static int[][] stickCounter;
    private int[] sticksPicked;
    private static int picked = 3;

    public void newnumberofsticks()
    {
        int[][] TAarray = new int[stickCounter.length][picked - 1];
        for (int i = 0; i < stickCounter.length; i++) {
            for (int j = 0; j <= picked - 2; j++) {
                TAarray[i][j] = stickCounter[i][j];
            }
        }
        stickCounter = new int[stickCounter.length][picked];
        for (int x = 0; x < TAarray.length; x++) {
            for (int y = 0; y <= picked - 2; y++) {
                stickCounter[x][y] = TAarray[x][y];
            }
            stickCounter[x][picked - 1] = sticksPicked[x];
        }
    }

    public void setStickPick(int sticksleft, int rand)
    {
        sticksPicked[sticksleft] = rand;
    }
    public static void newsticksetter(int[][] stickcounting, int stickscounted)
    {
        stickCounter = stickcounting;
        picked = stickscounted;
    }
    public void newGame()
    {
        picked++;
    }

    public int[][] getStickCounter()
    {
        return stickCounter;
    }

    public int[] getSticksPicked()
    {
        return sticksPicked;
    }

    public static int getPicked()
    {
        return picked;
    }
    
    public int getRand(int remainingsticks, int rand)
    {
        return stickCounter[remainingsticks - 1][rand];
    }
    
    public Computer(int num1)
    {
        sticksPicked = new int[num1];
        if(stickCounter == null)
        {
            stickCounter = new int [num1][picked];
            for(int i = 0; i < num1; i++)
            {
                for(int j = 0; j < 3; j++)
                {
                    stickCounter[i][j] = j + 1;
                }
            }
        }        
    }
}