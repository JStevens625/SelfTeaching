/* 
 * DOCUMENTED: Derick Vigne helped with the making of this code 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Jacob Stevens
 */
public class RunGame
{
    public static void main(String[] args)
    {
        Game main = new Game();
    }
}
