/* 
 * DOCUMENTED: Derick Vigne helped with the making of this code
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Jacob Stevens
 */
// DBMC = Dont break my code!!!!!
import java.util.Scanner;
import java.security.SecureRandom;
import java.util.Arrays;

public class Game
{

    public int randompickup(int numstick, SecureRandom rand, Computer com)
    {
        int pick = 0;
        while (pick == 0) {
            pick = com.getRand(numberOfSticks, rand.nextInt(com.getPicked()));
            while (pick > numberOfSticks) {
                pick = com.getRand(numberOfSticks, rand.nextInt(com.getPicked()));
            }
        }
        if (numberOfSticks == 3) {
            pick = 2;
        }
        else if (numberOfSticks <= 2) {
            pick = 1;
        }
        return pick;
    }

    public int DBMConlyints()
    {
        while (!input.hasNextInt()) {
            System.out.print("Please use a whole number: ");
            input.next();

        }
        return input.nextInt();
    }

    public int numberOfSticks;
    Scanner input = new Scanner(System.in);
    SecureRandom SC = new SecureRandom();

    public Game()
    {
        System.out.println("How many sticks would you like to use during this play session?");
        numberOfSticks = DBMConlyints();
        while (true) {
            System.out.println("What type of game would you like to play?");
            System.out.println("1. Player Vs. Player");
            System.out.println("2. Player Vs. Computer");
            System.out.println("3. Train AI");
            int Gametype = DBMConlyints();
            switch (Gametype) {
                case 1:
                    PvP(numberOfSticks);
                    break;
                case 2:
                    PvAI(numberOfSticks);
                    break;
                case 3:
                    TrainAI(numberOfSticks);
                    break;
            }
        }
    }

    private int DBMC1to3(int playerchoice)
    {
        while (playerchoice < 1 || playerchoice > 3) {
            System.out.print("Error! You broke my game!!!! nah JK but please only input 1, 2, or 3: ");
            playerchoice = input.nextInt();
        }
        return playerchoice;
    }

    public void PvP(int num)
    {
        Player hooman1 = new Player();
        Player hooman2 = new Player();
        while (num != 0) {
            System.out.println(num + " is the number of sticks left to pick up");
            System.out.print("Player 1 Please pick up (1-3) sticks: ");
            int player1moves = DBMConlyints();
            player1moves = DBMC1to3(player1moves);

            while (player1moves > num) {
                System.out.print("You can't pick up more sticks than the ones that exist! Please Try Again: ");
                player1moves = input.nextInt();
            }

            num -= player1moves;

            if (num == 0) {
                System.out.println("Player 2 Has Won!!! Relish in your victory!!!");
                break;
            }

            System.out.println(num + " is the number of sticks left to pick up");
            System.out.print("Player 2 Please pick up (1-3) sticks: ");
            int player2moves = DBMConlyints();
            player2moves = DBMC1to3(player2moves);

            while (player2moves > num) {
                System.out.print("You can't pick up more sticks than the ones that exist! Please Try Again: ");
                player2moves = input.nextInt();
            }

            num -= player2moves;

            if (num == 0) {
                System.out.println("Player 1 Has Won!!! Relish in your victory!!!");
                break;
            }
        }
    }

    public void PvAI(int num)
    {
        Player hooman1 = new Player();
        Computer comp = new Computer(num);
        while (num != 0) {
            System.out.println(num + " is the number of sticks left to pick up");
            System.out.print("Player 1 Please pick up (1-3) sticks: ");
            int player1moves = DBMConlyints();
            player1moves = DBMC1to3(player1moves);

            while (player1moves > num) {
                System.out.print("You can't pick up more sticks than the ones that exist! Please Try Again: ");
                player1moves = input.nextInt();
            }

            num -= player1moves;

            if (num == 0) {
                System.out.println("The A.I. Has Won :( ");
                comp.newGame();
                comp.newnumberofsticks();
                Computer.newsticksetter(comp.getStickCounter(), Computer.getPicked());
                break;
            }
            System.out.println(num + " is the number of sticks left to pick up");
            int picker = randompickup(num, SC, comp);
            while (picker > num) {
                picker = randompickup(num, SC, comp);
            }
            num -= picker;
            comp.setStickPick(num, picker);
            System.out.println("Computer took " + picker + " sticks");
            if (num == 0) {
                System.out.println("Player 1 Has Won!!! Relish in your victory!!!");
                break;
            }
        }
    }

    public void TrainAI(int num)
    {
        System.out.println("How many rounds do you wish to train the A.I. (Please do not pick more than 10,000 at a time)");
        int numofrounds = DBMConlyints();
        Computer comp1 = new Computer(num);
        Computer comp2 = new Computer(num);
        final int restart = num;
        for (int i = 0; i < numofrounds; i++) {
            num = restart;
            while (num > 0) {
                int pickcomp1 = randompickup(num, SC, comp1);
                while (pickcomp1 > num) {
                    pickcomp1 = randompickup(num, SC, comp1);
                }
                num -= pickcomp1;
                comp1.setStickPick(num, pickcomp1);
                if (num == 0) {
                    comp2.newGame();
                    comp2.newnumberofsticks();
                    Computer.newsticksetter(comp1.getStickCounter(), comp1.getPicked());
                    break;
                }
                int pickcomp2 = randompickup(num, SC, comp2);
                while (pickcomp2 > num) {
                    pickcomp2 = randompickup(num, SC, comp2);
                }
                num -= pickcomp2;
                comp1.setStickPick(num, pickcomp2);
                if (num == 0) {
                    comp1.newGame();
                    comp1.newnumberofsticks();
                    Computer.newsticksetter(comp2.getStickCounter(), comp2.getPicked());
                    break;
                }
            }
        }
    }
}
