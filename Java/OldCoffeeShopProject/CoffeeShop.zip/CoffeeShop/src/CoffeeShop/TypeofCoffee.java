/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CoffeeShop;

/**
 *
 * @author Jacob Stevens
 */
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class TypeofCoffee
{

    JPanel jp = new JPanel();

    public TypeofCoffee()
    {

        ButtonGroup bg = new ButtonGroup();
        ImageIcon i1 = new ImageIcon(getClass().getResource("Coffee.jpg"), BorderLayout.NORTH);
        ImageIcon i2 = new ImageIcon(getClass().getResource("Mocha.png"), BorderLayout.CENTER);
        ImageIcon i3 = new ImageIcon(getClass().getResource("Latte.jpg"), BorderLayout.SOUTH);
        JLabel jl = new JLabel("Type");
        jl.setFont(new Font("", Font.BOLD, 25));
        JPanel vert = new JPanel();
        vert.setLayout(new GridLayout(3, 2, 0, 0));
        JRadioButton b1 = new JRadioButton("Coffee");
        JRadioButton b2 = new JRadioButton("Mocha");
        JRadioButton b3 = new JRadioButton("Latte");
        JLabel j1 = new JLabel(i1);
        JLabel j2 = new JLabel(i2);
        JLabel j3 = new JLabel(i3);

        bg.add(b1);
        bg.add(b2);
        bg.add(b3);

        vert.add(b1);
        vert.add(j1);
        vert.add(b2);
        vert.add(j2);
        vert.add(b3);
        vert.add(j3);
        

        jp.add(vert);
    }
}
