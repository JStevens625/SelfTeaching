/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CoffeeShop;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

/**
 *
 * @author Jacob Stevens
 */
public class SizeofCoffee
{

    JPanel jp = new JPanel();
    JLabel jl = new JLabel();

    public SizeofCoffee()
    {
        ButtonGroup bg = new ButtonGroup();
        JLabel jl = new JLabel("Size");
        jl.setFont(new Font("Size", Font.BOLD, 25));
        JRadioButton b1 = new JRadioButton("Tall");
        JRadioButton b2 = new JRadioButton("Grande");
        JRadioButton b3 = new JRadioButton("Venti");
        JPanel vert = new JPanel();
        vert.setLayout(new GridLayout(4, 1, 0, 30));
        vert.add(jl);
        vert.add(b1);
        vert.add(b2);
        vert.add(b3);
        bg.add(b1);
        bg.add(b2);
        bg.add(b3);
        jp.add(vert);
    }
}
