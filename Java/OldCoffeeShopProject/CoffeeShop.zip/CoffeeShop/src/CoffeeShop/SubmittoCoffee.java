/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CoffeeShop;

import java.awt.event.MouseAdapter;
import javafx.scene.input.MouseEvent;
import static javafx.scene.input.MouseEvent.MOUSE_CLICKED;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JButton;

/**
 *
 * @author Jacob Stevens
 */
public class SubmittoCoffee
{

    JButton jb = new JButton("Submit");
    JPanel jp = new JPanel();

    public SubmittoCoffee()
    {
        jp.add(jb);
    }
}
