/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CoffeeShop;

import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

/**
 *
 * @author Jacob Stevens
 */
public class ExtrasforCoffee
{

    JPanel jp = new JPanel();

    public ExtrasforCoffee()
    {
        JLabel jl = new JLabel("Extras");
        jl.setFont(new Font("", Font.BOLD, 25));
        JRadioButton b1 = new JRadioButton("Sugar");
        JRadioButton b2 = new JRadioButton("Milk");
        JRadioButton b3 = new JRadioButton("Cream");
        JRadioButton b4 = new JRadioButton("Extra Shot");
        JPanel vert = new JPanel();
        vert.setLayout(new GridLayout(6, 1, 0, 30));
        vert.add(jl);
        vert.add(b1);
        vert.add(b2);
        vert.add(b3);
        vert.add(b4);
        jp.add(vert);
    }
}
