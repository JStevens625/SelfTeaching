/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CoffeeShop;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JPanel;

/**
 *
 * @author Jacob Stevens
 */
public class TestCoffeeShop
{

    public static void main(String[] args)
    {
        JFrame window = new JFrame("Galaxy Coffee");
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        Dimension dm = Toolkit.getDefaultToolkit().getScreenSize();
        Title title = new Title();
        SizeofCoffee size = new SizeofCoffee();
        TypeofCoffee type = new TypeofCoffee();
        ExtrasforCoffee extra = new ExtrasforCoffee();
        SubmittoCoffee submit = new SubmittoCoffee();
        double sWidth = dm.getWidth();
        double sHeight = dm.getHeight();
        double mWidth = sWidth / 1.5;
        double mHeight = sHeight / 1.5;
        window.setBounds(400, 100, (int) mWidth, (int) mHeight);
        window.setVisible(true);
        window.setResizable(true);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.add(panel);
        panel.add(title.jp, BorderLayout.NORTH);
        panel.add(submit.jp, BorderLayout.SOUTH);
        panel.add(type.jp, BorderLayout.CENTER);
        panel.add(size.jp, BorderLayout.WEST);
        panel.add(extra.jp, BorderLayout.EAST);

    }
}
