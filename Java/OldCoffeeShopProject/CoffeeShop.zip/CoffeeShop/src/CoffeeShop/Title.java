/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CoffeeShop;

import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Jacob Stevens
 */
public class Title
{

    JPanel jp = new JPanel();

    public Title()
    {
        ImageIcon sb = new ImageIcon(getClass().getResource("star.png"));
        JLabel label = new JLabel("Coffee Shop", sb, JLabel.LEFT);
        label.setFont(new Font("", Font.BOLD, 40));
        jp.add(label);
    }
}
